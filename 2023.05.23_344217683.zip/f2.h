#define F2_H

double f2(double);