#define F3_H

double f3(double);