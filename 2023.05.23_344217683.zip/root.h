extern int iterations;

double root(double (*func_f)(double), double (*func_g)(double), double a, double b, double eps1);