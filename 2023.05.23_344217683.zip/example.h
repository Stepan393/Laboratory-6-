#define EXAMPLE_H
double ex_f1(double x);
double ex_f2(double x);
double ex_f3(double x);