#include <math.h>

double ex_f1(double x) {
    return x*x;
}

double ex_f2(double x) {
    return sin(x);
}

double ex_f3(double x) {
    return 0.5*sqrt(x);
}
