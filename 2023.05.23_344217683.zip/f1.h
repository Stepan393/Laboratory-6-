#define F1_H

double f1(double);
